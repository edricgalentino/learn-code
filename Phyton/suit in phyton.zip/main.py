print("""
Selamat datang di game suit jepang!
Silahkan masukkan pilihan sesuai pilihan yang tersedia

Pilihan:
1. Gajah
2. Orang
3. Semut

note: pilihan harus memiliki huruf dan kata yang persis sama dengan pilihan yang tersedia.
""")
pilihan_player = input("Pilihanmu... ")
pilihan_yang_tersedia = ["Gajah", "Semut", "Orang"]
# cek pilihan yang tidak tersedia
while pilihan_player not in pilihan_yang_tersedia:
  print("""
Wah, pilihanmu kelihatannya gak sesuai deh. Silahkan pilih yang sesuai dan baca notes yaa
  """)
  pilihan_player = input("Pilihanmu... ")
  
print("""
Computer menentukan pilihan...
""")
# menentukan pilihan computer
import random
random_int_computer = random.randint(1,3)
pilihan_computer = ""
if random_int_computer == 1 :
  pilihan_computer = "Gajah"
elif random_int_computer == 2:
  pilihan_computer = "Orang"
else:
  pilihan_computer = "Semut"

# peraturan
hasil = ""
if pilihan_player == "Gajah":
  if pilihan_computer == "Gajah":
    hasil = f"Seri! kamu memilih {pilihan_player} dan Computer memilih {pilihan_computer}."
  elif pilihan_computer == "Orang":
    hasil = f"Kamu menang! kamu memilih {pilihan_player} dan Computer memilih {pilihan_computer}."
  else:
    hasil = f"Kamu kalah! kamu memilih {pilihan_player} dan Computer memilih {pilihan_computer}."
  print(hasil)

elif pilihan_player == "Orang":
  if pilihan_computer == "Orang":
    hasil = f"Seri! kamu memilih {pilihan_player} dan Computer memilih {pilihan_computer}."
  elif pilihan_computer == "Semut":
    hasil = f"Kamu menang! kamu memilih {pilihan_player} dan Computer memilih {pilihan_computer}."
  else:
    hasil = f"Kamu kalah! kamu memilih {pilihan_player} dan Computer memilih {pilihan_computer}."
  print(hasil)

elif pilihan_player == "Semut":
  if pilihan_computer == "Semut":
    hasil = f"Seri! kamu memilih {pilihan_player} dan Computer memilih {pilihan_computer}."
  elif pilihan_computer == "Gajah":
    hasil = f"Kamu menang! kamu memilih {pilihan_player} dan Computer memilih {pilihan_computer}."
  else:
    hasil = f"Kamu kalah! kamu memilih {pilihan_player} dan Computer memilih {pilihan_computer}."
  print(hasil)